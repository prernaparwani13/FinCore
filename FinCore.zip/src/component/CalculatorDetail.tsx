import React, { useState, useEffect } from 'react';
import {
  ArrowLeft, Share2, Download, Info, BookOpen,
  FileText, Moon, Zap, CircleCheck
} from 'lucide-react';

interface Props {
  calc?: any;
  onBack: () => void;
}

const CalculatorDetail: React.FC<Props> = ({ calc, onBack }) => {
  // 1. State for interactive sliders
  const [monthlyInv, setMonthlyInv] = useState(500);
  const [interest, setInterest] = useState(8);
  const [years, setYears] = useState(10);

  // State for dark mode toggle
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Effect to set initial state based on localStorage or system preference
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      setIsDarkMode(savedTheme === 'dark');
    } else {
      setIsDarkMode(window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
  }, []);

  // Effect to apply the class to the <html> element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  // Toggle theme function
  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  // 2. Calculation Logic for SIP
  const ratePerMonth = (interest / 100) / 12;
  const months = years * 12;
  
  // Future Value Formula: FV = P × ({[1 + i]^n - 1} / i) × (1 + i)
  const totalValue = Math.round(
    monthlyInv * ((Math.pow(1 + ratePerMonth, months) - 1) / ratePerMonth) * (1 + ratePerMonth)
  );
  
  const totalInvested = monthlyInv * months;
  const estReturns = totalValue - totalInvested;

  // 3. Donut Chart Math (Circumference of r=76 is ~477)
  const circumference = 2 * Math.PI * 76;
  const returnPercentage = (estReturns / totalValue) * 100;
  const offset = circumference - (returnPercentage / 100) * circumference;

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-slate-950 pb-20 font-sans text-slate-900 dark:text-slate-100">
      {/* Navbar */}
      <nav className="w-full bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 px-2 sm:px-4 md:px-8 py-4 mb-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white font-bold">F</div>
            <span className="text-xl font-black tracking-tighter">FinCore</span>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={toggleTheme} className="p-2 text-slate-400 cursor-pointer"><Moon size={20} /></button>
            <button className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-bold cursor-pointer">Get Started</button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-10 gap-4">
          <div className="flex items-center gap-4 sm:gap-6">
            <button onClick={onBack} className="w-12 h-12 bg-white dark:bg-slate-800 rounded-full shadow-sm border border-slate-100 dark:border-slate-700 hover:border-blue-500 cursor-pointer flex items-center justify-center">
              <ArrowLeft size={20} className="text-slate-600 dark:text-slate-300" />
            </button>
            <div>
              <div className="text-blue-600 text-[10px] font-black uppercase tracking-[0.2em] mb-1">{calc?.category || "MORTGAGE & LOANS"}</div>
              <h1 className="text-xl sm:text-2xl md:text-4xl font-black tracking-tight">{calc?.title || "Auto Loan"}</h1>
            </div>
          </div>

        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
          {/* Inputs */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-[2.5rem] p-4 sm:p-6 md:p-10 border border-slate-100 dark:border-slate-800 shadow-sm">
            <div className="flex items-center gap-2 text-slate-400 text-[11px] mb-10 font-bold uppercase tracking-widest">
              <Info size={14} /> Adjust values to see projections
            </div>
            
            <div className="space-y-8">
              <div>
                <div className="flex flex-col sm:justify-between sm:items-center sm:flex-row mb-3">
                  <label className="text-sm font-bold text-slate-600">Monthly Investment</label>

                <div className="flex items-center bg-blue-50 dark:bg-blue-900/30 text-blue-600 px-2 py-1 rounded-lg font-black text-sm transition-all border border-transparent focus-within:border-blue-200">
  {/* The Prefix */}
  <span className="select-none">$</span>

  {/* The Input */}
  <input
    type="number"
    min="100"
    max="10000"
    step="100"
    value={monthlyInv}
    onChange={(e) => setMonthlyInv(Number(e.target.value))}
    className="bg-transparent w-12 h-5 leading-none outline-none border-none p-0 ml-1 focus:ring-0 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
  />
</div>

                </div>
                <input type="range" min="100" max="10000" step="100" value={monthlyInv} onChange={(e) => setMonthlyInv(Number(e.target.value))} className="w-full h-1.5 bg-slate-100 rounded-full appearance-none cursor-pointer accent-blue-600" />
                <div className="flex justify-between text-[10px] font-bold text-slate-300 mt-2"><span>$100</span><span>$10k</span></div>
              </div>

              <div>
                <div className="flex flex-col sm:justify-between sm:items-center sm:flex-row mb-6">
                  <label className="text-sm font-bold text-slate-600 mb-2 sm:mb-0">Expected Return (p.a)</label>
                  <div className="bg-emerald-50 text-emerald-600 px-2 sm:px-4 py-1.5 rounded-lg font-black text-sm self-start sm:self-auto">{interest} %</div>
                </div>
                <input type="range" min="1" max="30" step="0.5" value={interest} onChange={(e) => setInterest(Number(e.target.value))} className="w-full h-1.5 bg-slate-100 rounded-full appearance-none cursor-pointer accent-emerald-500" />
                <div className="flex justify-between text-[10px] font-bold text-slate-300 mt-3"><span>1%</span><span>30%</span></div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-6">
                  <label className="text-sm font-bold text-slate-600">Time Period</label>
                  <div className="bg-indigo-50 text-indigo-600 px-4 py-1.5 rounded-lg font-black text-sm uppercase">{years} Years</div>
                </div>
                <input type="range" min="1" max="40" value={years} onChange={(e) => setYears(Number(e.target.value))} className="w-full h-1.5 bg-slate-100 rounded-full appearance-none cursor-pointer accent-indigo-600" />
                <div className="flex justify-between text-[10px] font-bold text-slate-300 mt-3"><span>1 Yr</span><span>40 Yrs</span></div>
              </div>
            </div>
          </div>

          {/* Results Sidebar with Blue Donut Chart */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-4 sm:p-6 md:p-10 border border-slate-100 dark:border-slate-800 text-center flex flex-col items-center shadow-sm">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-2">TOTAL VALUE</p>
              <h2 className="text-3xl sm:text-5xl font-black mb-2">$ {totalValue.toLocaleString()}</h2>
              <p className="text-emerald-500 font-bold text-xs mb-10 italic">Result after {years} years</p>

              {/* Blue Circle / Donut Chart */}
              <div className="relative w-32 h-32 sm:w-48 sm:h-48 mb-10">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 192 192">
                  <circle cx="96" cy="96" r="76" fill="transparent" stroke="#f1f5f9" strokeWidth="18" />
                  <circle
                    cx="96" cy="96" r="76" fill="transparent" stroke="#3b82f6" strokeWidth="18"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                    className="transition-all duration-500 ease-out"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">TOTAL</p>
                  <p className="text-xl font-black text-slate-900 dark:text-white">${(totalValue / 1000).toFixed(1)}k</p>
                </div>
              </div>

              <div className="w-full space-y-3">
                <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800 rounded-2xl">
                  <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-slate-200" /><span className="text-xs font-bold text-slate-500">Invested Amount</span></div>
                  <span className="text-sm font-black">$ {totalInvested.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800 rounded-2xl">
                  <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-blue-500" /><span className="text-xs font-bold text-slate-500">Est. Returns</span></div>
                  <span className="text-sm font-black">$ {estReturns.toLocaleString()}</span>
                </div>
              </div>
            </div>
            
          </div>
        </div>

        {/* Info Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <div className="bg-white dark:bg-slate-900 rounded-[2rem] p-4 sm:p-6 md:p-8 border border-slate-100 dark:border-slate-800">
              <h3 className="font-bold mb-4 flex items-center gap-3">
                <div className="p-2 bg-blue-50 rounded-lg"><BookOpen size={18} className="text-blue-600" /></div>
                How it works
              </h3>
              <p className="text-slate-500 text-sm leading-relaxed mb-6">This calculator uses the compound interest formula to project the future value of your regular monthly investments. It assumes the interest is compounded annually (or monthly depending on settings) and added back to the principal.</p>
              <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-100 text-center">
                <code className="text-blue-600 font-bold text-sm block italic">
                  {"FV = P × (([1 + i]^n - 1) / i) × (1 + i)"}
                </code>
              </div>
              <div className='text-slate-400 text-sm leading-relaxed mb-6'>Where: FV = Future Value, P = Monthly Investment, i = Monthly Interest Rate, n = Total Months</div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-[2rem] p-6 sm:p-8 border border-slate-100 dark:border-slate-800">
              <h3 className="font-bold mb-6 flex items-center gap-3">
                <div className="p-2 bg-emerald-50 rounded-lg"><Zap size={18} className="text-emerald-600" /></div>
                When to use this?
              </h3>
              <div className="space-y-4">
                {[
                  "Planning for long-term wealth creation.",
                  "Comparing investment vehicles (Mutual Funds vs. Stocks).",
                  "Understanding the power of compounding (10+ years)."
                ].map((text, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CircleCheck size={18} className="text-emerald-500 mt-1 shrink-0" />
                    <span className="text-sm font-medium text-slate-600 dark:text-slate-400">{text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-[2rem] p-4 sm:p-6 md:p-10 border border-slate-100 dark:border-slate-800 h-full">
            <h3 className="font-bold mb-10 flex items-center gap-3">
              <div className="p-2 bg-indigo-50 rounded-lg"><FileText size={18} className="text-indigo-600" /></div>
              Key Terms
            </h3>
            <div className="space-y-10">
              <div>
                <p className="font-black text-blue-600 text-sm mb-2">Principal Amount <Info size={14} className="inline ml-1 text-slate-300" /></p>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">The initial amount of money you invest. In a Monthly Investment Plan (SIP), this is the sum of your monthly contributions.</p>
              </div>
              <div>
                <p className="font-black text-blue-600 text-sm mb-2">Compound Frequency <Info size={14} className="inline ml-1 text-slate-300" /></p>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">How often interest is added back to the principal. More frequent compounding usually results in higher returns.</p>
              </div>
              <div>
                <p className="font-black text-blue-600 text-sm mb-2">Inflation Rate <Info size={14} className="inline ml-1 text-slate-300" /></p>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">The rate at which the general level of prices for goods and services is rising. It's important to consider inflation to understand the "real" value of your future returns.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalculatorDetail;