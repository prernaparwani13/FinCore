import React from 'react';

const Footer: React.FC = () => {
  const partners = [
    { name: 'Acme', icon: '■' },
    { name: 'Orbit', icon: '○' },
    { name: 'Vertex', icon: '◆' },
    { name: 'Solis', icon: '●' }
  ];

  return (
    <footer className="w-full bg-slate-100 dark:bg-slate-950 pt-10 pb-10 border-t border-slate-100 dark:border-slate-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-2">
        <div className="mt-12 pt-8 border-t border-slate-200 dark:border-slate-800">
          <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
            
            
          </div>
        </div>
        {/* Trusted By Section - Reduced Spacing */}
        <div className="flex flex-col items-center space-y-8">
          <p className="text-[15px] font-bold text-slate-400 dark:text-slate-500 tracking-[0.2em] uppercase">
            Trusted by teams at high-growth companies
          </p>
          
          <div className="flex flex-wrap justify-center items-center gap-15 md:gap-25 opacity-50 dark:opacity-40 grayscale scale-110">
            {partners.map((partner) => (
              <div key={partner.name} className="flex items-center space-x-2 cursor-default">
                <span className="text-xl text-slate-600 dark:text-slate-300">{partner.icon}</span>
                <span className="text-lg font-bold text-slate-700 dark:text-slate-200 tracking-tight">
                  {partner.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Copyright */}
       
      </div>
    </footer>
  );
};

export default Footer;