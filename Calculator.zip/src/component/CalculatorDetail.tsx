import Navbar from './Navbar';
import React, { useState, useEffect, useRef } from 'react';
import { useTheme } from '../hooks/useTheme';
import { useParams, useNavigate } from 'react-router-dom';
import { calculatorData } from '../Data/calculatorData';
import {
  ArrowLeft, Info, BookOpen,
  FileText, Zap, CircleCheck
} from 'lucide-react';

interface Props {
  calc?: any;
  onBack: () => void;
  showNavbar?: boolean;
}

const CALC_CONFIGS: Record<string, any> = {
  "SIP Calculator": {
    label1: "Monthly Investment", min1: 100, max1: 100000, step1: 100, def1: 100,
    label2: "Expected return(p.a.)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Time period", min3: 1, max3: 40, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
  calculate: (_monthly: number, _rate: number, _years: number) => {
  const monthly = Number(_monthly);        // SIP amount
  const annualRate = Number(_rate);        // % p.a.
  const years = Number(_years);

  const months = years * 12;
  const monthlyRate = annualRate / 100 / 12;

  // 1ï¸âƒ£ Invested Amount
  const investedAmount = monthly * months;

  // 2ï¸âƒ£ Total Value (Standard SIP Formula)
  const totalValue =
    monthly *
    ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) *
    (1 + monthlyRate);  
    
  // 3ï¸âƒ£ Estimated Returns
  const estimatedReturns = totalValue - investedAmount;

  return {
    totalInvested: Math.round(investedAmount),
    estReturns: Math.round(estimatedReturns),
    totalValue: Math.round(totalValue),
    years: Math.trunc(years),
    returnPercentage: +((estimatedReturns / investedAmount) * 100).toFixed(2),
    ratio: +((estimatedReturns / investedAmount) * 100).toFixed(2)
  };
},
    totalValueLabel: "Invested Amount",
    gainLabel: "TOTAL RETURN %",
    investedLabel: "Est. returns",
    profitLabel: "Total value",
    formulaText: "This SIP calculator uses the future value of an annuity formula:",
    formulaLatex: "FV = P Ã— [((1 + r)^n - 1) / r] Ã— (1 + r)",
    formulaVars: "FV = Future value, P = Monthly investment, r = Monthly interest rate, n = Number of months",
    useCases: [
      "Planning long-term savings through regular investments.",
      "Understanding the power of compounding with monthly contributions.",
      "Estimating future value of systematic investment plans."
    ],
    definitions: [
      { title: "Monthly Investment", desc: "The amount invested every month." },
      { title: "Expected return(p.a.)", desc: "The anticipated annual growth rate of the investment." },
      { title: "Time period", desc: "The duration over which investments are made." }
    ]
  },
  "Mortgage Payment": {
    type: 'loan',
    label1: "Loan Amount", min1: 5000, max1: 1000000, step1: 1000, def1: 5000,
    label2: "Interest Rate", min2: 0.1, max2: 15, step2: 0.1, def2: 0.1,
    label3: "Loan Term", min3: 1, max3: 30, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (loanAmount: number, rate: number, termYears: number) => {
      // 1. Force conversion to Numbers to prevent string concatenation or NaN errors
      const P = Number(loanAmount);
      const annualRate = Number(rate);
      const years = Number(termYears);

      const monthlyRate = annualRate / 100 / 12;
      const numPayments = years * 12;

      let monthlyPayment = 0;

      // 2. Handle the edge case of 0% interest rate
      if (annualRate === 0) {
        monthlyPayment = P / numPayments;
      } else {
        // 3. The Formula: M = P [ i(1 + i)^n ] / [ (1 + i)^n â€“ 1 ]
        const compoundFactor = Math.pow(1 + monthlyRate, numPayments);
        monthlyPayment = P * (monthlyRate * compoundFactor) / (compoundFactor - 1);
      }

      // 4. Derived totals for the summary and chart
      const totalRepayment = monthlyPayment * numPayments;
      const totalInterest = totalRepayment - P;

      return {
        // Main display: Monthly Payment (Rounded for clean UI)
        totalValue: (monthlyPayment),
        years: years,
        // Shows the annual rate (e.g., 6.5) so the label matches the slider
        returnPercentage: annualRate,
        totalInvested: Math.round(P),
        estReturns: (totalInterest),
        finalAmount: totalRepayment,
        // Ratio used for the blue progress ring (Interest vs Total Cost)
        ratio: (totalInterest / totalRepayment) * 100
      };
    },
    totalValueLabel: "MONTHLY PAYMENTS",
    gainLabel: "INTEREST RATE %",
    investedLabel: "Total Amount",
    profitLabel: "Total Interest",
    formulaText: "This mortgage calculator uses the standard loan payment formula:",
    formulaLatex: "M = P [ i(1 + i)^n ] / [ (1 + i)^n â€“ 1 ]",
    formulaVars: "M = Monthly payment, P = Loan amount, i = Monthly interest rate, n = Number of payments",
    useCases: [
      "Planning home purchases and understanding affordability.",
      "Comparing different loan terms and interest rates.",
      "Budgeting for long-term financial commitments."
    ],
    definitions: [
      { title: "Loan Amount", desc: "The original amount borrowed that needs to be repaid." },
      { title: "Interest Rate", desc: "The annual percentage charged by the lender for borrowing money." },
      { title: "Loan Term", desc: "The duration over which the loan is repaid, typically in years." }
    ]
},


  "Loan Amortization": {
    type: 'loan',
    label1: "Loan Amount", min1: 5000, max1: 1000000, step1: 1000, def1: 5000,
    label2: "Interest Rate", min2: 0.1, max2: 15, step2: 0.1, def2: 0.1,
    label3: "Loan Term", min3: 1, max3: 30, step3: 1, def3: 30,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (loanAmount: number, rate: number, termYears: number) => {
      const monthlyRate = rate / 100 / 12;
      const numPayments = termYears * 12;
      const monthlyPayment = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / (Math.pow(1 + monthlyRate, numPayments) - 1);
      const totalPayments = monthlyPayment * numPayments;
      const interest = totalPayments - loanAmount;
      return {
        totalValue: monthlyPayment,
        years: termYears,
        returnPercentage: (interest / loanAmount) * 100,
        totalInvested: Math.round(loanAmount),
        estReturns: interest,
        finalAmount: totalPayments,
        ratio: (interest / loanAmount) * 100
      };
    },
    totalValueLabel: "MONTHLY PAYMENT",
    gainLabel: "INTEREST %",
    investedLabel: "Loan Amount",
    profitLabel: "Total Interest",
    formulaText: "This amortization calculator uses the standard loan payment formula:",
    formulaLatex: "M = P [ i(1 + i)^n ] / [ (1 + i)^n â€“ 1 ]",
    formulaVars: "M = Monthly payment, P = Loan amount, i = Monthly interest rate, n = Number of payments",
    useCases: [
      "Understanding how loan payments are split between principal and interest.",
      "Planning debt payoff strategies.",
      "Comparing amortization schedules for different loans."
    ],
    definitions: [
      { title: "", desc: "The process of paying off a debt over time through regular payments." },
      { title: "Principal Payment", desc: "The portion of the payment that reduces the loan balance." },
      { title: "Interest Payment", desc: "The portion of the payment that covers the cost of borrowing." }
    ]
  },
  "Compound Interest": {
    label1: "Principal Amount", min1: 100, max1: 10000, step1: 100, def1: 100,
    label2: "Annual Interest Rate (%)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Time Period (Years)", min3: 1, max3: 40, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (principal: number, rate: number, years: number) => {
  const P = Number(principal);
  const r = Number(rate) / 100;
  const n = Number(years);

  const totalValue = P * Math.pow(1 + r, n);
  const interest = totalValue - P;

  return {
    totalValue: Math.round(totalValue),
    years: n,
    returnPercentage: +(interest / P * 100).toFixed(2),
    totalInvested: P,
    estReturns: Math.round(interest),
    ratio: +(interest / P * 100).toFixed(2)
  };
},

    totalValueLabel: "TOTAL INTEREST",
    gainLabel: "INTEREST %",
    investedLabel: "Initial Principal",
    profitLabel: "Total Interest",
    formulaText: "This calculator uses the standard compound interest formula for a lump sum investment:",
    
    formulaLatex: "FV = P(1 + r)^n", 
    formulaVars: "FV = Future Value, P = Principal, r = Annual Interest Rate, n = Number of Years",
    useCases: [
      "Visualizing how savings grow when interest is reinvested.",
      "Comparing long-term growth across different interest rates.",
      "Understanding the exponential nature of time in wealth building."
    ],
    definitions: [
      { title: "Compound Interest", desc: "Interest calculated on both the initial principal and the accumulated interest from previous periods." },
      { title: "Principal", desc: "The original sum of money invested or deposited." },
      { title: "Future Value", desc: "The total value of your investment at the end of the specified term." }
    ]
},
  "Retirement Planner": {
    type: 'loan',
    label1: "Monthly Contribution", min1: 100, max1: 10000, step1: 50, def1: 100,
    label2: "Expected Return (%)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Years to Retirement", min3: 1, max3: 40, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (monthly: number, rate: number, years: number) => {
  const P = Number(monthly);
  const r = Number(rate) / 100 / 12;
  const n = Number(years) * 12;

  let futureValue = 0;

  if (r === 0) {
    futureValue = P * n;
  } else {
    futureValue =
      P * ((Math.pow(1 + r, n) - 1) / r) * (1 + r);
  }

  const totalInvested = P * n;
  const interestEarned = futureValue - totalInvested;

  return {
    totalValue: Math.round(futureValue),
    totalInvested: Math.round(totalInvested),
    estReturns: Math.round(interestEarned),
    years,
    returnPercentage:
      totalInvested > 0
        ? +((interestEarned / totalInvested) * 100).toFixed(2)
        : 0,
    ratio:
      totalInvested > 0
        ? +((interestEarned / totalInvested) * 100).toFixed(2)
        : 0
  };
},
    totalValueLabel: "ESTIMATED NEST EGG",
    investedLabel: "Total Principal",
    profitLabel: "Interest Earned",
    formulaText: "This retirement calculator uses the future value of an annuity due formula, assuming contributions are made at the start of each month:",
    formulaLatex: "FV = P Ã— [((1 + r)^n - 1) / r] Ã— (1 + r)",
    formulaVars: "FV = Future value, P = Monthly contribution, r = Monthly interest rate, n = Total number of months",
    useCases: [
      "Visualizing how consistent monthly saving builds wealth.",
      "Understanding the impact of compound interest over decades.",
      "Setting realistic monthly savings goals for retirement."
    ],
    definitions: [
      { title: "Monthly Contribution", desc: "The amount you plan to save or invest at the beginning of every month." },
      { title: "Expected Return", desc: "The estimated annual interest rate or stock market growth (expressed as a percentage)." },
      { title: "Nest Egg", desc: "The total amount of money you will have accumulated by the time you retire." }
    ]
},
  "ROI Calculator": {
    type: 'loan',
    label1: "Amount Invested", min1: 100, max1: 100000, step1: 100, def1: 100,
    label2: "Amount Returned", min2: 100, max2: 200000, step2: 100, def2: 100,
    hasThirdSlider: false,
    isV2Currency: true,
    calculate: (invested: number, returned: number) => {
      const netProfit = returned - invested;
      const roi = (netProfit / invested) * 100;
      return {
        totalValue: netProfit,
        years: 1,
        returnPercentage: roi,
        totalInvested: Math.round(invested),
        estReturns: netProfit,
        finalAmount: returned,
        ratio: roi
      };
    },
    totalValueLabel: "PROFIT/LOSS",
    gainLabel: "ROI %",
    investedLabel: "Invested",
    profitLabel: "Profit",
    formulaText: "This ROI calculator uses the return on investment formula:",
    formulaLatex: "ROI = (Net Profit / Cost of Investment) x 100",
    formulaVars: "ROI = Return on investment percentage, Net Profit = Gain - Cost, Cost of Investment = Initial investment",
    useCases: [
      "Evaluating the efficiency of investments.",
      "Comparing profitability of different projects.",
      "Measuring performance of business ventures."
    ],
    definitions: [
      { title: "Return on Investment", desc: "A measure of the profitability of an investment." },
      { title: "Gain from Investment", desc: "The profit earned from the investment." },
      { title: "Cost of Investment", desc: "The initial amount invested." }
    ]
  },
  "GST Calculator": {
    label1: "Price", min1: 5000, max1: 500000, step1: 100, def1: 5000,
    label2: "GST Rate", min2: 5, max2: 30, step2: 1, def2: 5,
    hasThirdSlider: false,
    isV2Currency: false,
   calculate: (price: number, rate: number) => {
  const gstAmount = price * (rate / 100);
  const totalPrice = price + gstAmount;

  return {
    totalValue: totalPrice,  
    totalInvested: price,     
    estReturns: gstAmount,    
    returnPercentage: rate,
    years: 1,
    ratio: rate
  };
},

    totalValueLabel: "TOTAL PRICE(Including GST)",
    gainLabel: "GST RATE %",
    investedLabel: "Price Excluding GST",
    profitLabel: "GST Amount",
    formulaText: "This GST calculator calculates the Goods and Services Tax:",
    formulaLatex: "GST Amount = Price Ã— (GST Rate / 100), Total Price = Price + GST Amount",
    formulaVars: "GST Amount = Tax amount, Price = Original price, GST Rate = Tax percentage, Total Price = Price including GST",
    useCases: [
      "Calculating GST for goods and services.",
      "Understanding tax implications on purchases.",
      "Planning budgets including GST."
    ],
    definitions: [
      { title: "GST", desc: "Goods and Services Tax, a value-added tax levied on most goods and services." },
      { title: "GST Rate", desc: "The percentage rate at which GST is applied." },
      { title: "Total Price", desc: "The original price plus the GST amount." }
    ]
  },
  "Simple Interest": {
    label1: "Principal Amount", min1: 100, max1: 1000000, step1: 100, def1: 100,
    label2: "Rate of Interest (%)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Time Period (Years)", min3: 1, max3: 30, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (principal: number, rate: number, time: number) => {
      const interest = principal * rate * time / 100;
      const totalAmount = principal + interest;
      return {
        totalValue: totalAmount,
        years: time,
        returnPercentage: (interest / principal) * 100,
        totalInvested: Math.round(principal),
        estReturns: interest,
        ratio: (interest / principal) * 100
      };
    },
    totalValueLabel: "TOTAL AMOUNT",
    gainLabel: "INTEREST %",
    investedLabel: "Principal Amount",
    profitLabel: "Total Interest",
    formulaText: "This simple interest calculator uses the basic interest formula:",
    formulaLatex: "SI = P Ã— R Ã— T / 100, Total Amount = P + SI",
    formulaVars: "SI = Simple Interest, P = Principal Amount, R = Rate of Interest (%), T = Time Period (Years)",
    useCases: [
      "Calculating interest on loans or savings without compounding.",
      "Understanding basic interest calculations for short-term investments.",
      "Planning simple interest-based financial products."
    ],
    definitions: [
      { title: "Principal Amount", desc: "The original sum of money invested or borrowed." },
      { title: "Rate of Interest", desc: "The percentage rate at which interest is calculated annually." },
      { title: "Time Period", desc: "The duration over which the interest is calculated, in years." },
      { title: "Simple Interest", desc: "The interest calculated only on the principal amount." }
    ]
  },
  "Auto Loan": {
    type: 'loan',
    label1: "Loan Amount", min1: 5000, max1: 150000, step1: 500, def1: 5000,
    label2: "Interest Rate", min2: 0.1, max2: 20, step2: 0.1, def2: 0.1,
    label3: "Loan Term", min3: 1, max3: 7, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (loanAmount: number, rate: number, termYears: number) => {
  const monthlyRate = rate / 100 / 12;
  const numPayments = termYears * 12;

  const monthlyPayment =
    loanAmount *
    (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
    (Math.pow(1 + monthlyRate, numPayments) - 1);

  const totalPayment = monthlyPayment * numPayments;
  const interest = totalPayment - loanAmount;

  return {
  totalValue: monthlyPayment,
  years: termYears,
  returnPercentage: (interest / loanAmount) * 100,
  totalInvested: loanAmount,
  estReturns: interest,
  finalAmount: totalPayment,
  ratio: (interest / totalPayment) * 100
};

},

    totalValueLabel: "Monthly PAYMENTS",

    investedLabel: "Total Amount",
    profitLabel: "Total Interest",
    formulaText: "This auto loan calculator uses the standard loan payment formula:",
    formulaLatex: "M = P [ i(1 + i)^n ] / [ (1 + i)^n â€“ 1 ]",
    formulaVars: "M = Monthly payment, P = Loan amount, i = Monthly interest rate, n = Number of payments",
    useCases: [
      "Planning vehicle purchases and financing.",
      "Comparing auto loan terms and rates.",
      "Understanding total cost of car ownership."
    ],
    definitions: [
      { title: "Auto Loan", desc: "A loan specifically for purchasing a vehicle." },
      { title: "Down Payment", desc: "The initial payment made when purchasing a vehicle." },
      { title: "Loan Term", desc: "The duration over which the auto loan is repaid." }
    ]
  },
  "FD Calculator": {
    label1: "Total Investment", min1: 100, max1: 1000000, step1: 100, def1: 100,
    label2: "Rate of Interest (%)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Time Period (Years)", min3: 1, max3: 40, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (principal: number, rate: number, years: number) => {
  const P = Number(principal);
  const r = Number(rate) / 100;
  const t = Number(years);
  const n = 4; // Quarterly compounding (standard FD)

  const totalValue = P * Math.pow(1 + r / n, n * t);
  const estReturns = totalValue - P;

  return {
    totalValue: Math.round(totalValue),
    years: t,
    returnPercentage: +((estReturns / P) * 100).toFixed(2),
    totalInvested: P,
    estReturns: Math.round(estReturns),
    ratio: +((estReturns / P) * 100).toFixed(2)
  };
},
 
    totalValueLabel: "TOTAL VALUE",
    gainLabel: "RETURN %",
    investedLabel: "Total Investment",
    profitLabel: "Est Returns",
    formulaText: "This investment calculator uses the simple interest formula:",
    formulaLatex: "SI = P Ã— R Ã— T / 100, Total Value = P + SI",
    formulaVars: "SI = Simple Interest, P = Principal, R = Rate of Interest (%), T = Time Period (Years)",
    useCases: [
      "Planning short-term investments.",
      "Estimating returns on fixed deposits.",
      "Comparing simple interest rates and time periods."
    ],
    definitions: [
      { title: "Total Investment", desc: "The initial amount invested." },
      { title: "Rate of Interest", desc: "The annual percentage rate at which interest is calculated." },
      { title: "Time Period", desc: "The duration over which the investment is held, in years." },
      { title: "Est Returns", desc: "The estimated interest earned from the investment." },
      { title: "Total Value", desc: "The total value of the investment including principal and interest." }
    ]
  },
  "Mutual Funds Returns": {
    label1: "Total Investment", min1: 100, max1: 1000000, step1: 100, def1: 100,
    label2: "Expected Rate (%)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Time Period (Years)", min3: 1, max3: 40, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (principal: number, rate: number, years: number) => {
      const P = Number(principal);
      const r = Number(rate) / 100;
      const t = Number(years);

      const totalValue = P * Math.pow(1 + r, t);
      const estReturns = totalValue - P;

      return {
        totalValue: Math.round(totalValue),
        years: t,
        returnPercentage: +((estReturns / P) * 100).toFixed(2),
        totalInvested: P,
        estReturns: Math.round(estReturns),
        ratio: +((estReturns / P) * 100).toFixed(2)
      };
    },
    totalValueLabel: "TOTAL VALUE",
    gainLabel: "RETURN %",
    investedLabel: "Invested Amount",
    profitLabel: "Est. Returns",
    formulaText: "This mutual funds calculator uses the compound interest formula:",
    formulaLatex: "FV = P Ã— (1 + r)^t",
    formulaVars: "FV = Future Value, P = Principal, r = Annual Interest Rate, t = Time Period (Years)",
    useCases: [
      "Planning long-term investments in mutual funds.",
      "Estimating future value of lump-sum investments.",
      "Comparing different expected return rates."
    ],
    definitions: [
      { title: "Total Investment", desc: "The initial amount invested in mutual funds." },
      { title: "Expected Rate", desc: "The anticipated annual growth rate of the mutual fund." },
      { title: "Time Period", desc: "The duration over which the investment is held." },
      { title: "Est. Returns", desc: "The estimated profit from the investment." },
      { title: "Total Value", desc: "The total value of the investment including principal and returns." }
    ]
  },
  "Inflation Calculator": {
    label1: "Current Cost", min1: 100, max1: 1000000, step1: 100, def1: 100,
    label2: "Rate of Inflation (%)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Time Period (Years)", min3: 1, max3: 50, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (currentCost: number, inflationRate: number, years: number) => {
      const P = Number(currentCost);
      const r = Number(inflationRate) / 100;
      const t = Number(years);

      const futureCost = P * Math.pow(1 + r, t);
      const costIncrease = futureCost - P;

      return {
        totalValue: Math.round(costIncrease),
        years: t,
        returnPercentage: inflationRate,
        totalInvested: P,
        estReturns: Math.round(futureCost),
        ratio: +((costIncrease / P) * 100).toFixed(2)
      };
    },
    totalValueLabel: "COST INCREASE",
    gainLabel: "",
    investedLabel: "Current Cost",
    profitLabel: "Future Cost",
    formulaText: "This inflation calculator uses the compound inflation formula:",
    formulaLatex: "FC = CC Ã— (1 + r)^t, CI = FC - CC",
    formulaVars: "FC = Future Cost, CC = Current Cost, r = Annual Inflation Rate, t = Time Period (Years), CI = Cost Increase",
    useCases: [
      "Estimating the impact of inflation on future expenses.",
      "Planning for cost increases in budgeting and savings.",
      "Understanding purchasing power erosion over time."
    ],
    definitions: [
      { title: "Current Cost", desc: "The present value of the item or expense." },
      { title: "Rate of Inflation", desc: "The expected annual percentage increase in prices." },
      { title: "Time Period", desc: "The number of years over which inflation is applied." },
      { title: "Cost Increase", desc: "The additional amount needed due to inflation." },
      { title: "Future Cost", desc: "The projected cost after accounting for inflation." }
    ]
  },
  "NPS Calculator": {
    label1: "Investment per month", min1: 100, max1: 100000, step1: 100, def1: 100,
    label2: "Expected Return (p.a.)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Your age", min3: 18, max3: 59, step3: 1, def3: 18,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (monthly: number, rate: number, age: number) => {
      const years = 60 - age;
      const monthlyRate = rate / 100 / 12;
      const numMonths = years * 12;
      const totalInvested = monthly * numMonths;
      const maturityAmount = Math.round(
        monthly * ((Math.pow(1 + monthlyRate, numMonths) - 1) / monthlyRate)
      );
      const interestEarned = maturityAmount - totalInvested;
      const minAnnuityInvestment = Math.round(0.4 * maturityAmount);
      return {
        totalValue: totalInvested,
        years,
        returnPercentage: (interestEarned / totalInvested) * 100,
        totalInvested,
        estReturns: interestEarned,
        maturityAmount,
        minAnnuityInvestment,
        ratio: (interestEarned / totalInvested) * 100
      };
    },
    totalValueLabel: "TOTAL INVESTMENT",
    gainLabel: "RETURN %",
    investedLabel: "Total Investment",
    profitLabel: "Interest Earned",
    formulaText: "This NPS calculator uses the future value of an annuity formula:",
    formulaLatex: "FV = P Ã— [((1 + r)^n - 1) / r] Ã— (1 + r)",
    formulaVars: "FV = Future value, P = Monthly investment, r = Monthly interest rate, n = Number of months",
    useCases: [
      "Planning retirement savings through NPS.",
      "Estimating maturity amount and annuity requirements.",
      "Understanding the impact of monthly contributions and expected returns."
    ],
    definitions: [
      { title: "Investment per month", desc: "The amount contributed monthly to NPS." },
      { title: "Expected Return (p.a.)", desc: "The anticipated annual growth rate of NPS investments." },
      { title: "Your age", desc: "Current age, used to calculate years until retirement at 60." },
      { title: "Total Investment", desc: "Total amount invested over the period." },
      { title: "Interest Earned", desc: "Total returns generated from investments." },
      { title: "Maturity Amount", desc: "Total value at retirement." },
      { title: "Min. Annuity Investment", desc: "Minimum amount required for annuity purchase (40% of maturity)." }
    ]
  },
  "RD Calculator": {
    label1: "Monthly Investment", min1: 100, max1: 100000, step1: 100, def1: 100,
    label2: "Rate of Interest (p.a.)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Time Period", min3: 0, max3: 120, step3: 1, def3: 0,
    hasThirdSlider: true,
    hasFourthSlider: false,
    isV2Currency: false,
    timeUnit: 'Years',
  calculate: (
    monthly: number,
    rate: number,
    timePeriod: number,
    timeUnit: string
  ) => {
    const n = timeUnit === "Years" ? timePeriod * 12 : timePeriod;
    const r = rate / 400; 

    let maturityValue = 0;
    if (rate > 0 && n > 0) {
      const totalQuarters = n / 3;
      const numerator = Math.pow(1 + r, totalQuarters) - 1;
      const denominator = 1 - Math.pow(1 + r, -1/3);
      
      maturityValue = monthly * (numerator / denominator);
    } else {
      maturityValue = monthly * n;
    }
    const totalInvested = monthly * n;
    const finalMaturity = Math.floor(maturityValue);
    const estReturns = finalMaturity - totalInvested;
    return {
      totalValue: finalMaturity,
      totalInvested,
      estReturns,
      timePeriod,
      timeUnit,
      returnPercentage: (estReturns / totalInvested) * 100,
      ratio: (estReturns / totalInvested) * 100
    };
  },
    totalValueLabel: "Invested Amount",
    gainLabel: "RETURN %",
    investedLabel: "Invested Amount",
    profitLabel: "Est. Returns",
    formulaText: "This RD calculator uses the future value of an annuity formula with monthly compounding:",
    formulaLatex: "FV = P Ã— [((1 + r/12)^n - 1) / (r/12)] Ã— (1 + r/12)",
    formulaVars: "FV = Future value, P = Monthly investment, r = Annual interest rate, n = Total months",
    useCases: [
      "Planning savings through recurring deposits.",
      "Estimating returns on fixed monthly investments.",
      "Comparing RD rates and time periods."
    ],
    definitions: [
      { title: "Monthly Investment", desc: "The amount deposited every month." },
      { title: "Rate of Interest (p.a.)", desc: "The annual interest rate offered on the RD." },
      { title: "Time Period", desc: "The duration for which the RD is held, in years and months." },
      { title: "Invested Amount", desc: "Total amount deposited over the period." },
      { title: "Est. Returns", desc: "Estimated interest earned." },
      { title: "Total Value", desc: "Maturity value including principal and interest." }
    ]
  },
  "SSY Calculator": {
    label1: "Yearly Investment", min1: 250, max1: 150000, step1: 5000, def1: 250,
    label2: "Girl's Age", min2: 1, max2: 10, step2: 1, def2: 1,
    label3: "Start Year", min3: 2021, max3: 2030, step3: 1, def3: 2021,

    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (yearly:number, age:number, startYear:number) => {
  const rate = 0.085201075;   // 8.5201%

  const maturityYears = 21 - age;
  const depositYears = Math.max(0, 15 - age);

  let balance = 0;
  let totalInvested = 0;

  for (let year = 1; year <= maturityYears; year++) {
    balance *= (1 + rate);

    if (year <= depositYears) {
      balance += yearly;
      totalInvested += yearly;
    }
  }

  const maturityValue = Math.round(balance);
  const totalInterest = maturityValue - totalInvested;

  return {
    totalValue: totalInvested,
    totalInvested,
    estReturns: totalInterest,
    maturityValue,
    maturityYear: startYear + maturityYears,
    returnPercentage: +((totalInterest / totalInvested) * 100).toFixed(2),
    ratio: (depositYears / 15) * 100  // Use deposit years as ratio for dynamic chart
  };
},
    totalValueLabel: "TOTAL INVESTMENT",
    gainLabel: "RETURN %",
    investedLabel: "Total Investment",
    profitLabel: "Total Interest",
    formulaText: "This SSY calculator uses the future value of an annuity formula with annual compounding:",
    formulaLatex: "FV = P Ã— [((1 + r)^n - 1) / r] Ã— (1 + r)^m",
    formulaVars: "FV = Maturity Value, P = Yearly Investment, r = Annual Interest Rate (8.2%), n = Investment Years, m = Remaining Years to Maturity",
    useCases: [
      "Planning savings for girl child's education and marriage.",
      "Estimating maturity value of SSY investments.",
      "Comparing different investment amounts and periods."
    ],
    definitions: [
      { title: "Yearly Investment", desc: "The amount invested annually in the SSY account (â‚¹250 to â‚¹1.5 lakh)." },
      { title: "Girl's Age", desc: "Current age of the girl child (0-10 years)." },
      { title: "Start Year", desc: "The year when the investment starts (2021-2030)." },
      { title: "Total Investment", desc: "Total amount invested over the contribution period." },
      { title: "Total Interest", desc: "Total interest earned on the investment." },
      { title: "Maturity Year", desc: "The year when the account matures (at age 21)." },
      { title: "Maturity Value", desc: "The total amount available at maturity." }
    ]
  },
  "SWP Calculator": {
    label1: "Total Investment", min1: 10000, max1: 10000000, step1: 1000, def1: 10000,
    label2: "Withdraw per month", min2: 100, max2: 100000, step2: 100, def2: 100,
    label3: "Expected return rate", min3: 1, max3: 20, step3: 0.1, def3: 1,
    label4: "Time period", min4: 1, max4: 50, step4: 1, def4: 10,
    hasThirdSlider: true,
    hasFourthSlider: true,
    isV2Currency: false,
    isV4Currency: false,
    calculate: (
  totalInvestment: number,
  withdrawPerMonth: number,
  expectedReturn: number,
  timePeriodYears: number
) => {
  const monthlyRate = expectedReturn / 100 / 12;
  const totalMonths = timePeriodYears * 12;

  const totalWithdrawal = withdrawPerMonth * totalMonths;

  const growthFactor = Math.pow(1 + monthlyRate, totalMonths);

  const finalValue =
  totalInvestment * growthFactor -
  withdrawPerMonth * ((growthFactor - 1) / monthlyRate);


  const estReturns =
    totalWithdrawal + finalValue - totalInvestment;

  return {
    totalValue: Math.round(totalWithdrawal),
    totalInvested: totalInvestment,
    finalValue: Math.max(0, Math.round(finalValue)),
    estReturns: Math.round(estReturns),
    returnPercentage:
      ((estReturns / totalInvestment) * 100).toFixed(2),
    years: timePeriodYears,
    ratio: (totalWithdrawal / totalInvestment).toFixed(2),
  };
},
    totalValueLabel: "TOTAL WITHDRAWAL",
    investedLabel: "Final value",
    profitLabel: "Total Investment",
    formulaText: "This SWP calculator simulates monthly withdrawals from an investment with compound interest over a specified time period.",
    formulaLatex: "Balance = (Balance Ã— (1 + r)) - W",
    formulaVars: "Balance = Current balance, r = Monthly interest rate, W = Monthly withdrawal, Time period = Specified years",
    useCases: [
      "Planning retirement income through systematic withdrawals.",
      "Estimating withdrawal amounts over a specific time period.",
      "Understanding the impact of withdrawal amounts and time horizons on investment longevity."
    ],
    definitions: [
      { title: "Total Investment", desc: "The initial lump sum amount invested." },
      { title: "Withdraw per month", desc: "The fixed amount withdrawn every month." },
      { title: "Expected return rate", desc: "The anticipated annual growth rate of the investment." },
      { title: "Time period", desc: "The number of years over which withdrawals will be made." },
      { title: "Total Withdrawal", desc: "The total amount withdrawn over the specified period." },
      { title: "Final Value", desc: "The remaining balance after the specified time period." }
    ]
  },
  "PPF Calculator": {
    label1: "Yearly Investment", min1: 500, max1: 150000, step1: 500, def1: 500,
    label2: "Time Period", min2: 15, max2: 50, step2: 1, def2: 15,
    hasThirdSlider: false,
    isV2Currency: false,
    calculate: (yearlyInvestment: number, timePeriod: number) => {
  const rate = 0.071; // Fixed 7.1%
  const years = timePeriod;

  let balance = 0;
  let totalInvested = 0;

  for (let year = 1; year <= years; year++) {
    // 1. Add the investment first
    balance += yearlyInvestment;
    totalInvested += yearlyInvestment;

    // 2. Apply interest to the balance (including the new investment)
    balance *= (1 + rate);
  }

  const maturityValue = Math.round(balance);
  const totalInterest = maturityValue - totalInvested;

  return {
    totalValue: totalInvested, // Keeping your key names
    totalInvested,
    estReturns: totalInterest,
    maturityValue,
    returnPercentage: +((totalInterest / totalInvested) * 100).toFixed(2),
    ratio: (totalInterest / totalInvested) * 100
  };
},
    totalValueLabel: "Invested Amount",
    gainLabel: "RETURN %",
    investedLabel: "Total Interest",
    profitLabel: "Maturity Value",
    formulaText: "This PPF calculator uses the future value of an annuity formula with annual compounding at 7.1% interest rate:",
    formulaLatex: "FV = P Ã— [((1 + r)^n - 1) / r] Ã— (1 + r)",
    formulaVars: "FV = Maturity Value, P = Yearly Investment, r = Annual Interest Rate (7.1%), n = Number of Years",
    useCases: [
      "Planning long-term savings through PPF.",
      "Estimating maturity value and interest earned.",
      "Understanding the benefits of tax-free savings."
    ],
    definitions: [
      { title: "Yearly Investment", desc: "The amount invested annually in the PPF account (â‚¹500 to â‚¹1.5 lakh)." },
      { title: "Time Period", desc: "The duration for which the investment is held (15-50 years)." },
      { title: "Invested Amount", desc: "Total amount invested over the period." },
      { title: "Total Interest", desc: "Total interest earned on the investment." },
      { title: "Maturity Value", desc: "The total value available at maturity." }
    ]
  },
  "Lumpsum Calculator": {
    label1: "Total Investment", min1: 100, max1: 1000000, step1: 100, def1: 100,
    label2: "Expected Rate (p.a.)", min2: 1, max2: 20, step2: 0.1, def2: 1,
    label3: "Time period", min3: 1, max3: 40, step3: 1, def3: 1,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (principal: number, rate: number, years: number) => {
      const P = Number(principal);
      const r = Number(rate) / 100;
      const t = Number(years);

      const totalValue = P * Math.pow(1 + r, t);
      const estReturns = totalValue - P;

      return {
        totalValue: Math.round(totalValue),
        years: t,
        returnPercentage: +((estReturns / P) * 100).toFixed(2),
        totalInvested: P,
        estReturns: Math.round(estReturns),
        ratio: +((estReturns / P) * 100).toFixed(2)
      };
    },
    totalValueLabel: "TOTAL VALUE",
    gainLabel: "RETURN %",
    investedLabel: "Est. Returns",
    profitLabel: "Invested Amount",
    formulaText: "This lumpsum calculator uses the compound interest formula for a lump sum investment:",
    formulaLatex: "FV = P Ã— (1 + r)^t",
    formulaVars: "FV = Future Value, P = Principal, r = Annual Interest Rate, t = Time Period (Years)",
    useCases: [
      "Planning long-term investments with a single lump sum.",
      "Estimating future value of one-time investments.",
      "Comparing different expected return rates for lump sum investments."
    ],
    definitions: [
      { title: "Total Investment", desc: "The initial amount invested as a lump sum." },
      { title: "Expected Rate (p.a.)", desc: "The anticipated annual growth rate of the investment." },
      { title: "Time period", desc: "The duration over which the investment is held." },
      { title: "Est. Returns", desc: "The estimated profit from the investment." },
      { title: "Total Value", desc: "The total value of the investment including principal and returns." }
    ]
  },
  "SCSS Calculator": {
    label1: "Yearly Investment", min1: 100, max1: 100000, step1: 100, def1: 1000,
    label2: "Tenure", min2: 5, max2: 5, step2: 1, def2: 5,
    label3: "Rate of Interest", min3: 8.2, max3: 8.2, step3: 0.1, def3: 8.2,
    hasThirdSlider: true,
    isV2Currency: false,
    calculate: (yearlyInvestment: number, tenure: number, rate: number) => {
  const P = Number(yearlyInvestment);
  const years = Number(tenure); 
  const annualRate = Number(rate) / 100;

  const quarters = years * 4;

  // Quarterly interest (simple interest)
  const quarterlyInterest = (P * annualRate) / 4;

  // Total interest over entire tenure
  const totalInterest = quarterlyInterest * quarters;

  // Maturity value = Principal + total interest
  const maturityValue = P + totalInterest;

  return {
    totalValue: Math.round(quarterlyInterest), // quarterly payout
    years: years,
    returnPercentage: +((totalInterest / P) * 100).toFixed(2),
    totalInvested: Math.round(P),
    estReturns: Math.round(totalInterest),
    maturityValue: Math.round(maturityValue),
    ratio: +((totalInterest / P) * 100).toFixed(2)
  };
},

    totalValueLabel: "QUARTERLY RECEIVABLE INTEREST",
    gainLabel: "RETURN %",
    investedLabel: "Total Interest",
    profitLabel: "Maturity Value",
    formulaText: "This SCSS calculator uses compound interest with quarterly compounding for yearly investments over a fixed tenure.",
    formulaLatex: "FV = âˆ‘ P Ã— (1 + r/4)^{quarters remaining}",
    formulaVars: "FV = Maturity Value, P = Yearly Investment, r = Annual Interest Rate, quarters = Total quarters",
    useCases: [
      "Planning savings for senior citizens with fixed tenure and interest rate.",
      "Estimating quarterly interest and total returns on SCSS investments.",
      "Understanding the impact of yearly investments on maturity value."
    ],
    definitions: [
      { title: "Yearly Investment", desc: "The amount invested annually in the SCSS scheme." },
      { title: "Tenure", desc: "The fixed duration of the investment, set at 5 years." },
      { title: "Rate of Interest", desc: "The fixed annual interest rate, set at 8.2%." },
      { title: "Quarterly Receivable Interest", desc: "The interest earned and receivable each quarter." },
      { title: "Total Interest", desc: "The total interest earned over the tenure." },
      { title: "Maturity Value", desc: "The total value at the end of the tenure including principal and interest." }
    ]
  },
  "Post Office MIS Calculator": {
    label1: "Invested Amount", min1: 1000, max1: 450000, step1: 1000, def1: 10000,
    label2: "Interest Rate", min2: 6.6, max2: 7.4, step2: 0.1, def2: 6.6,
    hasThirdSlider: false,
    isV2Currency: false,
    calculate: (principal: number, rate: number) => {
      const P = Number(principal);
      const r = Number(rate) / 100;
      const monthlyIncome = (P * r) / 12;
      const totalInvested = P;
      const totalIncome = monthlyIncome * 60; // 5 years * 12 months
      const estReturns = totalIncome - P;

      return {
        totalValue: Math.round(monthlyIncome),
        totalInvested: P,
        estReturns: Math.round(estReturns),
        returnPercentage: rate,
        years: 5,
        ratio: (estReturns / P) * 100
      };
    },
    totalValueLabel: "MONTHLY Income",
    gainLabel: "INTEREST RATE %",
    investedLabel: "Total Investment",
    profitLabel: "Total Income",
    formulaText: "This Post Office MIS calculator calculates monthly income based on invested amount and interest rate:",
    formulaLatex: "Monthly Income = (Principal Ã— Rate) Ã· 12",
    formulaVars: "Principal = Invested Amount, Rate = Annual Interest Rate (%), Monthly Income = Amount received monthly",
    useCases: [
      "Planning regular monthly income from Post Office investments.",
      "Understanding returns from Monthly Income Scheme.",
      "Comparing MIS with other fixed income options."
    ],
    definitions: [
      { title: "Invested Amount", desc: "The lump sum amount invested in Post Office MIS (â‚¹1,000 to â‚¹4.5 lakh)." },
      { title: "Interest Rate", desc: "The annual interest rate offered on the MIS investment." },
      { title: "Invested Amount", desc: "The monthly income received from the investment." },
      { title: "Interest Rate", desc: "The annual percentage rate at which interest is calculated." }
    ]
  },
  "Gratuity Calculator": {
    label1: "Monthly Salary (Basic+DA)", min1: 10000, max1: 200000, step1: 1000, def1: 30000,
    label2: "Years of Service", min2: 1, max2: 30, step2: 1, def2: 5,
    hasThirdSlider: false,
    isV2Currency: false,
    calculate: (monthlySalary: number, years: number) => {
      const gratuity = (monthlySalary * 15 * years) / 26;
      return {
        totalValue: Math.round(gratuity),
        totalInvested: monthlySalary,
        estReturns: years,
        returnPercentage: 0,
        years: years,
        ratio: 0
      };
    },
    totalValueLabel: "TOTAL GRATUITY PAYABLE",
    gainLabel: "",
    investedLabel: "Monthly Salary",
    profitLabel: "Years of Service",
    formulaText: "This Gratuity calculator calculates the gratuity amount based on monthly salary and years of service:",
    formulaLatex: "Gratuity = (Monthly Salary Ã— 15 Ã— Years of Service) Ã· 26",
    formulaVars: "Monthly Salary = Basic + DA, Years of Service = Number of years worked",
    useCases: [
      "Calculating gratuity for employees upon retirement or resignation.",
      "Understanding gratuity benefits in employment contracts.",
      "Planning for retirement benefits."
    ],
    definitions: [
      { title: "Monthly Salary (Basic+DA)", desc: "The monthly basic salary plus dearness allowance." },
      { title: "Years of Service", desc: "The number of years the employee has served the organization." },
      { title: "Gratuity", desc: "A lump sum payment made to an employee upon retirement or resignation." }
    ]
  },
  "Income Tax Calculator": {
    calculate: (grossSalary: number, otherSources: number, interestIncome: number, rentalIncome: number, homeLoanInterestSelf: number, homeLoanInterestLetOut: number, deduction80C: number, deduction80CCD1B: number, deduction80D: number, deduction80G: number, deduction80E: number, deduction80TTA: number, basicSalary: number, da: number, hraReceived: number, rentPaid: number, isMetro: number, ageCategory: number) => {
      // Calculate total income
      const totalIncome = grossSalary + otherSources + interestIncome + rentalIncome;

      // Calculate deductions
      const totalDeductions = deduction80C + deduction80CCD1B + deduction80D + deduction80G + deduction80E + deduction80TTA;

      // Calculate HRA exemption
      const hraExemption = Math.min(hraReceived, rentPaid - (basicSalary + da) * 0.1, (basicSalary + da) * (isMetro ? 0.5 : 0.4));

      // Calculate taxable income (after standard deduction of â‚¹50,000)
      const taxableIncome = Math.max(0, totalIncome - totalDeductions - hraExemption - 50000);

      // Helper function to calculate tax
      const calculateTax = (income: number, slabs: number[][]) => {
        let tax = 0;
        for (const [limit, rate] of slabs) {
          if (income > limit) {
            tax += (income - limit) * rate;
            break;
          }
        }
        return tax;
      };

      // New regime slabs (2023 onwards)
      const newRegimeSlabs = [
        [300000, 0],
        [700000, 0.05],
        [1000000, 0.1],
        [1200000, 0.15],
        [1500000, 0.2],
        [Infinity, 0.3]
      ];

      // Old regime slabs
      const oldRegimeSlabs = [
        [250000, 0],
        [500000, 0.05],
        [1000000, 0.2],
        [Infinity, 0.3]
      ];

      const newRegimeTax = calculateTax(taxableIncome, newRegimeSlabs) + calculateTax(taxableIncome, newRegimeSlabs) * 0.04; // 4% cess
      const oldRegimeTax = calculateTax(taxableIncome, oldRegimeSlabs) + calculateTax(taxableIncome, oldRegimeSlabs) * 0.04; // 4% cess

      return {
        totalValue: Math.round(newRegimeTax),
        totalInvested: Math.round(oldRegimeTax),
        estReturns: Math.round(taxableIncome),
        returnPercentage: 0,
        years: 0,
        ratio: 0
      };
    },
    totalValueLabel: "TOTAL TAX (NEW REGIME)",
    gainLabel: "",
    investedLabel: "Total Tax (Old Regime)",
    profitLabel: "Taxable Income",
    formulaText: "This calculator computes income tax under new and old regimes based on Indian tax laws.",
    formulaLatex: "",
    formulaVars: "",
    useCases: [
      "Calculate tax liability for salaried individuals.",
      "Compare tax under new and old regimes.",
      "Plan deductions and exemptions."
    ],
    definitions: [
      { title: "New Tax Regime", desc: "Simplified tax slabs with lower rates but fewer deductions." },
      { title: "Old Tax Regime", desc: "Traditional tax slabs with more deductions available." },
      { title: "Taxable Income", desc: "Income after deductions and exemptions." }
    ]
  },
};

function CalculatorDetail({ calc, onBack, showNavbar=true }: Props) {
  const navigate = useNavigate();

  const [currentCalc, setCurrentCalc] = useState(calc);

  useEffect(() => {
    if (calc) {
      setCurrentCalc(calc);
    }
  }, [calc]);

  const handleBack = onBack || (() => navigate(-1));

  const config = CALC_CONFIGS[currentCalc?.title] || CALC_CONFIGS["SIP Calculator"];

  const exchangeRate = 83;

  // State initialization using config defaults
  const [isINR, setIsINR] = useState(false); // Default to USD
  const [isExcludeGST, setIsExcludeGST] = useState(false);
  const [isMetro, setIsMetro] = useState(true); // Default to Metro for HRA
// Helper functions to get currency-adjusted config values
  const getCurrencyAdjustedValue = (value: number) => isINR ? value : value / exchangeRate;
  const getUSDEquivalent = (value: number) => isINR ? value / exchangeRate : value;

  const mountRef = useRef(0);

  useEffect(() => {
    mountRef.current += 1;
  });

  // State initialization 
const [v1, setV1] = useState(config.def1 || config.min1);
const [v2, setV2] = useState(config.def2 || config.min2);
const [v3, setV3] = useState(config.def3 ?? (config.min3 || (calc?.title === "SSY Calculator" ? 2024 : 0)));
const [v4, setV4] = useState(config.def4 ?? (config.min4 || 0));
const [timeUnit, setTimeUnit] = useState(config.timeUnit || 'Years');
const [inputV1, setInputV1] = useState((config.def1 || config.min1).toLocaleString());
const [inputV2, setInputV2] = useState(config.isV2Currency ? (config.def2 || config.min2).toLocaleString() : (config.def2 || config.min2).toString());
const [inputV3, setInputV3] = useState(calc?.title === "SSY Calculator" ? ((config.def3 || config.min3) ?? 2024).toString() : ((config.def3 || config.min3) ?? 10).toLocaleString());
const [inputV4, setInputV4] = useState(((config.def4 || config.min4) ?? 0).toLocaleString());
const [inputTimePeriod, setInputTimePeriod] = useState((config.def3 || config.min3 || 10).toLocaleString());
  const dynamicConfig =
  calc?.title === "GST Calculator" && isExcludeGST
    ? {
        ...config,
        label1: "Price (Including GST)",

        calculate: (amount: number, rate: number) => {
          const basePrice = amount / (1 + rate / 100);
          const gstAmount = amount - basePrice;

          return {
            totalValue: Math.round(basePrice),
            totalInvested: Math.round(basePrice),
            estReturns: Math.round(gstAmount),
            returnPercentage: rate,
            years: 1,
            ratio: rate
          };
        },

        totalValueLabel: "PRICE EXCLUDING GST",
        investedLabel: "PRICE EXCLUDING GST",
        profitLabel: "GST AMOUNT",

        formulaText: "GST removed from inclusive price:",
        formulaLatex:
          "Base Price = Amount Ã· (1 + GST Rate / 100)",
        formulaVars:
          "Amount = Price including GST, GST Rate = Tax percentage"
      }
    : config;


  // Determine if calculator has multiple sliders
  const hasMultipleSliders = dynamicConfig.label2 || dynamicConfig.hasThirdSlider;

  // // Use values directly for calculations (assuming INR)
  // const calcV1 = v1;
  // const calcV2 = dynamicConfig.isV2Currency ? v2 : v2;
   const calcV1 = isINR ? v1 : v1 * exchangeRate;
 const calcV2 = dynamicConfig.isV2Currency ? (isINR ? v2 : v2 * exchangeRate) : v2;
  const calcV3 = v3;
  const calcV4 = v4;

  const results = calc?.title === "Income Tax Calculator" ? dynamicConfig.calculate(grossSalary, otherSources, interestIncome, rentalIncome, homeLoanInterestSelf, homeLoanInterestLetOut, deduction80C, deduction80CCD1B, deduction80D, deduction80G, deduction80E, deduction80TTA, basicSalary, da, hraReceived, rentPaid, isMetro ? 1 : 0, ageCategory === "Below 60" ? 0 : ageCategory === "60 or Above 60" ? 1 : 2) : calc?.title === "RD Calculator" ? dynamicConfig.calculate(calcV1, calcV2, calcV3, timeUnit) : dynamicConfig.hasFourthSlider ? dynamicConfig.calculate(calcV1, calcV2, calcV3, calcV4) : dynamicConfig.hasThirdSlider ? dynamicConfig.calculate(calcV1, calcV2, calcV3) : dynamicConfig.calculate(calcV1, calcV2);
  const { totalValue, years, timePeriod, returnPercentage, totalInvested, estReturns, finalAmount } = results || {};

  const { theme } = useTheme();
  const adjustedMin1 = getCurrencyAdjustedValue(dynamicConfig.min1);
  const adjustedMax1 = getCurrencyAdjustedValue(dynamicConfig.max1);
  const adjustedMin2 = dynamicConfig.label2 ? (dynamicConfig.isV2Currency ? getCurrencyAdjustedValue(dynamicConfig.min2) : dynamicConfig.min2) : 0;
  const adjustedMax2 = dynamicConfig.label2 ? (dynamicConfig.isV2Currency ? getCurrencyAdjustedValue(dynamicConfig.max2) : dynamicConfig.max2) : 0;
  const adjustedMin3 = dynamicConfig.hasThirdSlider ? dynamicConfig.min3 : 0;
  const adjustedMax3 = dynamicConfig.hasThirdSlider ? dynamicConfig.max3 : 0;
  const adjustedMin4 = dynamicConfig.hasFourthSlider ? (dynamicConfig.isV4Currency ? getCurrencyAdjustedValue(dynamicConfig.min4) : dynamicConfig.min4) : 0;
  const adjustedMax4 = dynamicConfig.hasFourthSlider ? (dynamicConfig.isV4Currency ? getCurrencyAdjustedValue(dynamicConfig.max4) : dynamicConfig.max4) : 0;
  const percentage1 = Math.max(0, ((v1 - adjustedMin1) / (adjustedMax1 - adjustedMin1)) * 100);
  const percentage2 = dynamicConfig.label2 ? Math.max(0, ((v2 - adjustedMin2) / (adjustedMax2 - adjustedMin2)) * 100) : 0;
  const percentage3 = dynamicConfig.hasThirdSlider ? Math.max(0, ((v3 - adjustedMin3) / (adjustedMax3 - adjustedMin3)) * 100) : 0;
  const percentage4 = dynamicConfig.hasFourthSlider ? Math.max(0, ((v4 - adjustedMin4) / (adjustedMax4 - adjustedMin4)) * 100) : 0;
  const trackColor = theme === 'dark' ? '#1e293b' : '#f1f5f9';
  const progressColor = '#007bff';

  const formatCurrency = (amount: number) => {
    const val = isINR ? amount : amount / exchangeRate;
    return `${isINR ? 'â‚¹' : '$'} ${Math.round(val).toLocaleString()}`;
  };

  const radius = 76;
const circumference = 2 * Math.PI * radius;
const offset = circumference - (Math.min(results.ratio, 100) / 100) * circumference;



  useEffect(() => {
  window.scrollTo({ top: 0, left: 0, behavior: 'instant' });

  // Identify the correct defaults for the current specific calculator
  const defV1 = config.def1 || config.min1;
  const defV2 = config.def2 || config.min2;
  const defV3 = config.def3 ?? (calc?.title === "SSY Calculator" ? 2024 : 0);
  const defV4 = config.def4 ?? 0;

  // Sync Numeric States to defaults
  setV1(defV1);
  setV2(defV2);
  setV3(defV3);
  setV4(defV4);

  // Sync String Inputs (Ensuring the text box matches the slider exactly)
  setInputV1(defV1.toLocaleString());

  setInputV2(
    config.isV2Currency
      ? defV2.toLocaleString()
      : defV2.toString()
  );

  setInputV3(
    calc?.title === "SSY Calculator"
      ? defV3.toString()
      : defV3.toLocaleString()
  );

  setInputTimePeriod(defV3.toLocaleString());
  setInputV4(defV4.toLocaleString());

  setIsExcludeGST(false);
}, [calc?.title]);

  // Additional effect to ensure reset on every mount (for reopening same calculator)
  useEffect(() => {
    // Use 'def' (Default) values
    setV1(config.def1 || config.min1);
    setV2(config.def2 || config.min2);
    setV3(config.def3 || config.min3 || (calc?.title === "SSY Calculator" ? 2024 : 0));
    setV4(config.def4 || config.min4 || 0);

    setInputV1((config.def1 || config.min1).toLocaleString());
    setInputV2(config.isV2Currency ? (config.def2 || config.min2).toLocaleString() : (config.def2 || config.min2).toString());
    setInputV3(calc?.title === "SSY Calculator" ? (config.def3 || config.min3 || 2024).toString() : (config.def3 || config.min3 || 0).toLocaleString());
    setInputTimePeriod((config.def3 || config.min3 || 10).toLocaleString());
    setInputV4((config.def4 || config.min4 || 0).toLocaleString());

    setIsExcludeGST(false);
  }, []);

  useEffect(() => {
    // Reset to minimum values in the new currency
    // const newMin1 = getCurrencyAdjustedValue(config.min1);
    // setV1(newMin1);
    // setInputV1(Math.round(newMin1).toLocaleString());

    const convertValue = (currentValue: number) => isINR ? currentValue * exchangeRate : currentValue / exchangeRate;
    const newV1 = Math.min(Math.max(convertValue(v1), getCurrencyAdjustedValue(config.min1)), getCurrencyAdjustedValue(config.max1));
    setV1(newV1);
    setInputV1(Math.round(newV1).toLocaleString());


    if (config.isV2Currency) {
      const newV2 = Math.min(Math.max(convertValue(v2), getCurrencyAdjustedValue(config.min2)), getCurrencyAdjustedValue(config.max2));
     setV2(newV2);
     setInputV2(newV2.toLocaleString(undefined, { maximumFractionDigits: 2 }));
    }

    if (config.isV3Currency) {
      const newV3 = Math.min(Math.max(convertValue(v3), config.min3), config.max3);
      setV3(newV3);
      setInputV3(Math.round(newV3).toLocaleString());
    }

    if (config.hasFourthSlider) {
      const newV4 = Math.min(Math.max(convertValue(v4), getCurrencyAdjustedValue(config.min4)), getCurrencyAdjustedValue(config.max4));
    setV4(newV4);
    setInputV4(Math.round(newV4).toLocaleString());
    }
  }, [isINR, config.isV2Currency, config.isV3Currency, config.hasFourthSlider, exchangeRate]);

  return (
  <div className={`min-h-screen bg-[#f8fafc] dark:bg-slate-950 pb-20 font-sans text-slate-900 dark:text-white ${!showNavbar ? 'mt-8' : ''}`}>
    {showNavbar && <Navbar />}

    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-5 md:mb-5 gap-2 mt-[14px]">
        <div className="flex items-center gap-3 sm:gap-6">
          <button
            onClick={onBack}
            className="w-10 h-10 sm:w-12 sm:h-12 bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-slate-100 dark:border-slate-700 hover:border-blue-500 cursor-pointer flex items-center justify-center transition-all"
          >
            <ArrowLeft size={18} className="text-slate-600 dark:text-slate-400" />
          </button>
          <div className="flex flex-col items-start text-left">
            <div className="text-blue-600 dark:text-blue-400 text-[10px] sm:text-[14px] font-black uppercase tracking-[0.3em] sm:tracking-[0.5em] mb-1 mt-3 ">
              {calc?.category || "FINANCE"}
            </div>
            <h1 className="text-xl sm:text-2xl md:text-4xl font-black tracking-tight text-slate-900 dark:text-white">
              {calc?.title || "Calculator"}
            </h1>
          </div>
        </div>
      </div>

      {/* Main Grid: Stacked on mobile, 12-col on desktop */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 md:gap-6 mb-8">
        
        {/* Inputs Section */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-[1.5rem] sm:rounded-[2.5rem] p-4 sm:p-8 md:p-8 border border-slate-100 dark:border-slate-800 shadow-sm">
          <div className={` mt-[-13px] text-slate-400 text-[10px] ${hasMultipleSliders ? 'mb-8' : 'mb-4'} font-bold uppercase tracking-widest text-left`}>
            <Info size={14} className="inline mr-2" /> Adjust sliders or type values
          </div>
          {calc?.title === "GST Calculator" && (
            <div className="mb-4">

              <div className="flex items-center gap-6 mb-6">
                {/* Include GST Radio */}
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input
                    type="radio"
                    name="gstToggle"
                    checked={!isExcludeGST}
                    onChange={() => {
                      setIsExcludeGST(false);
                      const adjustedPrice = getCurrencyAdjustedValue(5000);
                      setV1(adjustedPrice);
                      setInputV1(adjustedPrice.toLocaleString());
                    }}
                    // accent-blue-600 ensures the radio dot is blue
                    className="w-4 h-4 accent-blue-600 cursor-pointer"
                  />
                  <span className={`text-sm font-medium transition-colors ${!isExcludeGST ? 'text-blue-600' : 'text-gray-500 hover:text-blue-400'}`}>
                    Include GST
                  </span>
                </label>

                {/* Exclude GST Radio */}
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input
                    type="radio"
                    name="gstToggle"
                    checked={isExcludeGST}
                    onChange={() => {
                      setIsExcludeGST(true);
                      const basePrice = v1 / (1 + (v2 / 100));
                      const adjustedBasePrice = getCurrencyAdjustedValue(basePrice);
                      setV1(adjustedBasePrice);
                      setInputV1(adjustedBasePrice.toLocaleString());
                    }}

                    // accent-blue-600 ensures the radio dot is blue
                    className="w-4 h-4 accent-blue-600 cursor-pointer"
                  />

                  <span className={`text-sm font-medium transition-colors ${isExcludeGST ? 'text-blue-600' : 'text-gray-500 hover:text-blue-400'}`}>
                    Exclude GST
                  </span>
                </label>
              </div>
            </div>
          )}

          {calc?.title === "Income Tax Calculator" && (
            <div className="space-y-6">
              {/* Assessment Year and Age Category */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Assessment Year</label>
                  <select
                    value={assessmentYear}
                    onChange={(e) => setAssessmentYear(e.target.value)}
                    className="w-full p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                  >
                    <option value="2024-2025">2024-2025</option>
                    <option value="2025-2026">2025-2026</option>
                  </select>
                </div>
              </div>
        
              {/* Deductions Section */}
              <div className="space-y-4">
                <h4 className="text-lg font-bold text-slate-700 dark:text-slate-300">Deductions under Chapter VI-A</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Life Insurance Premium u/s 80C</label>
                    <div className="flex items-center bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 px-3 py-1.5 rounded-lg border border-green-100 dark:border-green-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={deduction80C.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setDeduction80C(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">NPS Contribution u/s 80CCD(1B)</label>
                    <div className="flex items-center bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 px-3 py-1.5 rounded-lg border border-green-100 dark:border-green-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={deduction80CCD1B.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setDeduction80CCD1B(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Medical Insurance Premium u/s 80D</label>
                    <div className="flex items-center bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 px-3 py-1.5 rounded-lg border border-green-100 dark:border-green-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={deduction80D.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setDeduction80D(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Donation to Charity u/s 80G</label>
                    <div className="flex items-center bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 px-3 py-1.5 rounded-lg border border-green-100 dark:border-green-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={deduction80G.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setDeduction80G(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Interest on Educational Loan u/s 80E</label>
                    <div className="flex items-center bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 px-3 py-1.5 rounded-lg border border-green-100 dark:border-green-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={deduction80E.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setDeduction80E(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Interest on Deposits in Saving Account u/s 80TTA/TTB</label>
                    <div className="flex items-center bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 px-3 py-1.5 rounded-lg border border-green-100 dark:border-green-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={deduction80TTA.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setDeduction80TTA(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* HRA Exemption Section */}
              <div className="space-y-4">
                <h4 className="text-lg font-bold text-slate-700 dark:text-slate-300">HRA Exemption</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Basic Salary Received per Annum</label>
                    <div className="flex items-center bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 px-3 py-1.5 rounded-lg border border-purple-100 dark:border-purple-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={basicSalary.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setBasicSalary(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Dearness Allowance (DA) Received per Annum</label>
                    <div className="flex items-center bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 px-3 py-1.5 rounded-lg border border-purple-100 dark:border-purple-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={da.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setDa(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">HRA Received per Annum</label>
                    <div className="flex items-center bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 px-3 py-1.5 rounded-lg border border-purple-100 dark:border-purple-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={hraReceived.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setHraReceived(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Total Rent Paid per Annum</label>
                    <div className="flex items-center bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 px-3 py-1.5 rounded-lg border border-purple-100 dark:border-purple-800/50">
                      <span className="mr-1">₹</span>
                      <input
                        type="text"
                        value={rentPaid.toLocaleString()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          setRentPaid(Number(val) || 0);
                        }}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 block">Do you live in a metro city?</label>
                    <select
                      value={isMetro ? "Yes" : "No"}
                      onChange={(e) => setIsMetro(e.target.value === "Yes")}
                      className="w-full p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                    >
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Slider 1: Investment / Principal / Amount */}
          <div
            className="relative w-full h-1.5 rounded-full"
            style={{
              background: `linear-gradient(to right, ${progressColor} 0%, ${progressColor} ${percentage2}%, ${trackColor} ${percentage2}%, ${trackColor} 100%)`,
            }}
          >
            <input
              type="range"
              min={adjustedMin2}
              max={adjustedMax2}
              step={dynamicConfig.step2 || 0.01} // decimal step
              value={v2}
              onChange={(e) => {
                const val = Math.round(parseFloat(e.target.value));
                setV2(val);
                setInputV2(
                  dynamicConfig.isV2Currency
                    ? val.toLocaleString()
                    : val.toString()
                );
              }}
              className="absolute inset-0 w-full h-full bg-transparent appearance-none cursor-pointer custom-slider"
            />
          </div>

          <div className="flex justify-between text-[10px] font-bold text-slate-300 mt-2 uppercase tracking-widest">
            <span>
              {config.isV2Currency || calc?.title === "SWP Calculator"
                ? `${config.min2}$`
                : calc?.title === "SSY Calculator" || calc?.title === "PPF Calculator" ? `${config.min2} Yr` : `${config.min2}%`}
            </span>
            <span>
              {config.isV2Currency || calc?.title === "SWP Calculator"
                ? `${config.max2}$`
                : calc?.title === "SSY Calculator" || calc?.title === "PPF Calculator" ? `${config.max2} Yr` : `${config.max2}%`}
            </span>
          </div>

          {/* Slider 3: Duration/Rate/Amount */}
          {config.hasThirdSlider && (
            <div className="mt-6">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4">
                <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 sm:mb-0 whitespace-nowrap">
                  {dynamicConfig.label3}
                </label>

                {/* Blue Styled Input Container - Width Reduced to w-32 (128px) */}
                <div className="flex items-center justify-between bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 px-3 py-1.5 rounded-lg border border-blue-100 dark:border-blue-800/50 w-29 h-10">
                  {calc?.title === "SCSS Calculator" && config.min3 === config.max3 ? (
                    <span className="font-black text-sm w-full text-center">
                      {config.min3}%
                    </span>
                  ) : (
                    <>
                      {calc?.title === "HRA Calculator" && <span className="mr-1">{isINR ? '₹' : '$'}</span>}
                      <input
                        type="text"
                        className="bg-transparent border-none outline-none text-right font-black w-full pr-1 text-sm"
                        value={calc?.title === "RD Calculator" ? inputTimePeriod : inputV3}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          // Allow only digits (integers) for amounts
                          if (!/^\d*$/.test(val)) return;
                          const setInput = calc?.title === "RD Calculator" ? setInputTimePeriod : setInputV3;
                          setInput(val);
                          const num = parseInt(val);
                          if (!isNaN(num)) setV3(num);
                        }}
                        onBlur={() => {
                          const clamped = Math.min(Math.max(v3, config.min3), config.max3);
                          setV3(Math.round(clamped));
                          if (calc?.title === "RD Calculator") setInputTimePeriod(Math.round(clamped).toString());
                          else setInputV3(Math.round(clamped).toLocaleString());
                        }}
                      />

                      {/* Dynamic Unit Label */}
                      <span className="text-[13px] font-bold uppercase ml-1 mt-[2px]">
                        {calc?.title === "SWP Calculator" ? "Yr" :
                        calc?.title === "RD Calculator" ? (timeUnit === "Years" ? "YRS" : "MTH") :
                        calc?.title === "HRA Calculator" ? "" :
                        "YRS"}
                      </span>
                    </>
                  )}
                </div>
              </div>

              {/* Range Slider Track */}
              {!(calc?.title === "SCSS Calculator" && config.min3 === config.max3) && (
                <>
                  <div className="relative w-full h-1.5 rounded-full" 
                      style={{ background: `linear-gradient(to right, ${progressColor} 0%, ${progressColor} ${percentage3}%, ${trackColor} ${percentage3}%, ${trackColor} 100%)` }}>
                    <input
                      type="range"
                      min={adjustedMin3}
                      max={adjustedMax3}
                      step={config.step3}
                      value={v3}
                      onChange={(e) => {
                        const val = Math.round(Number(e.target.value));
                        setV3(val);
                        const formatted = val.toLocaleString();
                        calc?.title === "RD Calculator" ? setInputTimePeriod(formatted) : setInputV3(formatted);
                      }}
                      className="custom-slider absolute inset-0 w-full h-full bg-transparent appearance-none cursor-pointer"
                    />
                  </div>
                  <div className="flex justify-between text-[10px] font-bold text-slate-300 mt-2 uppercase tracking-widest">
                    <span>{calc?.title === "HRA Calculator" ? formatCurrency(config.min3) : config.min3} {calc?.title === "RD Calculator" ? "Min" : calc?.title === "HRA Calculator" ? "" : "Yr"}</span>
                    <span>{calc?.title === "HRA Calculator" ? formatCurrency(config.max3) : config.max3} {calc?.title === "RD Calculator" ? "Max" : calc?.title === "HRA Calculator" ? "" : "Yrs"}</span>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Fixed Interest Rate Display for PPF Calculator */}
          {calc?.title === "PPF Calculator" && (
            <div className="mt-4">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-2">
                <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 sm:mb-0">
                  Interest Rate
                </label>
                <div className="flex items-center bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 px-7 py-1.5 rounded-lg font-black text-sm border border-emerald-100 dark:border-emerald-800/50">
                  7.1%
                </div>
              </div>
            </div>
          )}

          {/* Fixed Lock in Period Display for Post Office MIS Calculator */}
          {calc?.title === "Post Office MIS Calculator" && (
            <div className="mt-4">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-2">
                <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 sm:mb-0">
                  Lock in period
                </label>
                <div className="flex items-center bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 px-7 py-1.5 rounded-lg font-black text-sm border border-indigo-100 dark:border-indigo-800/50">
                  5yr
                </div>
              </div>
            </div>
          )}

          {/* Slider 4: Fourth Parameter */}
          {config.hasFourthSlider && (
            <div>
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4">
                <label className="text-sm font-bold text-slate-600 dark:text-slate-400 mb-2 sm:mb-0">
                  {dynamicConfig.label4}
                </label>
                <div className="flex items-center bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 px-3 py-1.5 rounded-lg font-black text-sm border border-purple-100 dark:border-purple-800/50 w-30">
                  {calc?.title === "RD Calculator" ? (
                    <select
                      value={v4}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setV4(val);
                        setInputV4(val.toString());
                      }}
                      className="bg-transparent border-none outline-none text-center w-full"
                    >
                      {Array.from({ length: 12 }, (_, i) => i).map((month) => (
                        <option key={month} value={month}>{month}</option>
                      ))}
                    </select>
                  ) : calc?.title === "SWP Calculator" ? (
                    <>
                      <input
                        type="text"
                        value={inputV4}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          if (val === '') {
                            setV4(0);
                            setInputV4('');
                            return;
                          }
                          const num = Number(val);
                          if (!isNaN(num)) {
                            const clamped = Math.min(
                              Math.max(num, 0),
                              adjustedMax4
                            );
                            setV4(clamped);
                            setInputV4(val);
                          }
                        }}
                        onBlur={() => setInputV4(v4 === 0 ? '0' : Math.round(v4).toLocaleString())}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                      <span className="ml-1 uppercase">Yr</span>
                    </>
                  ) : calc?.title === "Gratuity Calculator" ? (
                    <>
                      <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                        <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-blue-500" /><span className="text-xs font-bold text-slate-500">Monthly Salary</span></div>
                        <span className="text-sm font-black text-blue-600">{formatCurrency(totalInvested)}</span>
                      </div>
                      <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                        <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-green-500" /><span className="text-xs font-bold text-slate-500">Years of Service</span></div>
                        <span className="text-sm font-black text-blue-600">{estReturns}</span>
                      </div>
                    </>
                  ) : (
                    <>
                      <span className="mr-1">{isINR ? '₹' : '$'}</span>
                      <input
                        type="text"
                        value={inputV4}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => {
                          const val = e.target.value.replace(/,/g, '');
                          if (!/^\d*$/.test(val)) return;
                          if (val === '') {
                            setV4(0);
                            setInputV4('');
                            return;
                          }
                          const num = Number(val);
                          if (!isNaN(num)) {
                            const clamped = Math.min(
                              Math.max(num, 0),
                              adjustedMax4
                            );
                            setV4(clamped);
                            setInputV4(val);
                          }
                        }}
                        onBlur={() => setInputV4(v4 === 0 ? '0' : Math.round(v4).toLocaleString())}
                        className="bg-transparent border-none outline-none text-center w-full"
                      />
                    </>
                  )}
                </div>
              </div>
              <div className="relative w-full h-2 sm:h-1.5 rounded-full" style={{ background: `linear-gradient(to right, ${progressColor} 0%, ${progressColor} ${percentage4}%, ${trackColor} ${percentage4}%, ${trackColor} 100%)` }}>
                <input
                  type="range"
                  min={adjustedMin4}
                  max={adjustedMax4}
                  step={config.step4}
                  value={v4}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setV4(val);
                    setInputV4(val.toLocaleString());
                  }}
                  className="absolute inset-0 w-full h-full bg-transparent appearance-none cursor-pointer custom-slider"
                  style={{ '--thumb-color': progressColor } as React.CSSProperties}
                />
              </div>
              <div className="flex justify-between text-[10px] font-bold text-slate-300 mt-2 uppercase tracking-widest">
                <span>{calc?.title === "SWP Calculator" ? `${dynamicConfig.min4} Yr` : formatCurrency(dynamicConfig.min4)}</span>
                <span>{calc?.title === "SWP Calculator" ? `${dynamicConfig.max4} Yrs` : formatCurrency(dynamicConfig.max4)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Results Sidebar */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          <div className="bg-white dark:bg-slate-900 rounded-[1.5rem] sm:rounded-[2.5rem] p-4 sm:p-4 border border-slate-100 dark:border-slate-800 text-center flex flex-col items-center shadow-sm">
            <p className={`text-[10px] font-black uppercase tracking-[0.2em] mb-2 ${calc?.title === "ROI Calculator" && estReturns < 0 ? 'text-red-600' : 'text-slate-400'}`}>{calc?.title === "PPF Calculator" ? "MATURITY VALUE" : calc?.title === "ROI Calculator" ? (estReturns < 0 ? "LOSS" : "PROFIT") : dynamicConfig.totalValueLabel}</p>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black mb-2 break-all">{calc?.title === "PPF Calculator" ? formatCurrency(results.maturityValue) : calc?.title === "SIP Calculator" ? formatCurrency(totalInvested) : calc?.title === "RD Calculator" ? formatCurrency(totalInvested) : calc?.title === "Compound Interest" ? formatCurrency(estReturns) : calc?.title === "Lumpsum Calculator" ? formatCurrency(totalValue) : dynamicConfig.type==='loan'?formatCurrency(totalValue):formatCurrency(totalValue)}</h2>
            {dynamicConfig.hasThirdSlider && <p className="text-emerald-500 font-bold text-xs mb-4 italic"></p>}

            {/* Donut Chart: Scale for mobile */}
            <div className="relative w-6 h-36 sm:w-48 sm:h-48 mb-0.5">
              <svg className='w-full h-full transform -rotate-90' viewBox="0 0 192 192">
                <circle cx="96" cy="96" r={radius} fill="transparent" stroke="currentColor" className="text-slate-100 dark:text-slate-800" strokeWidth="38" />
                <circle cx="96" cy="96" r={radius} fill="transparent" stroke="#3b82f6" strokeWidth="38" strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round" className="transition-all duration-700 ease-in-out" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                {dynamicConfig.gainLabel && (
                  <>
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{dynamicConfig.gainLabel}</p>
                    <p className="text-lg sm:text-xl font-black">{returnPercentage.toFixed(1)}%</p>
                  </>
                )}
              </div>
            </div>

            {/* Currency Toggle: Center aligned for mobile */}
            <div className="w-full space-y-2 mt-[-24px]">
              <div className="flex justify-end">
                <button
                  onClick={() => setIsINR(!isINR)}
                  className="px-3 py-1 rounded-full text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors cursor-pointer"
                >
                  {isINR ? 'USD ($)' : 'INR (₹)'}
                </button>
              </div>
              {calc?.title === "SWP Calculator" ? (
                <>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-blue-500" /><span className="text-xs font-bold text-slate-500">Total Investment</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(totalInvested)}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-green-500" /><span className="text-xs font-bold text-slate-500">Final Value</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(estReturns)}</span>
                  </div>
                </>
              ) : calc?.title === "SSY Calculator" ? (
                <>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-blue-500" /><span className="text-xs font-bold text-slate-500">Total Interest</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(estReturns)}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-green-500" /><span className="text-xs font-bold text-slate-500">Maturity Year</span></div>
                    <span className="text-sm font-black text-blue-600">{results.maturityYear}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-purple-500" /><span className="text-xs font-bold text-slate-500">Maturity Value</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(results.maturityValue)}</span>
                  </div>
                </>
              ) : calc?.title === "PPF Calculator" ? (
                <>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-blue-500" /><span className="text-xs font-bold text-slate-500">Total Interest</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(estReturns)}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-purple-500" /><span className="text-xs font-bold text-slate-500">Invested Amount</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(totalInvested)}</span>
                  </div>
                </>
              ) : calc?.title === "SCSS Calculator" ? (
                <>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-blue-500" /><span className="text-xs font-bold text-slate-500">Total Interest</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(estReturns)}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-green-500" /><span className="text-xs font-bold text-slate-500">Maturity Value</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(results.maturityValue)}</span>
                  </div>
                </>
              ) : calc?.title === "HRA Calculator" ? (
                <>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-blue-500" /><span className="text-xs font-bold text-slate-500">Taxable HRA</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(estReturns)}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-green-500" /><span className="text-xs font-bold text-slate-500">Basic Salary</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(totalInvested)}</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-blue-500" /><span className="text-xs font-bold text-slate-500">{calc?.title === "SIP Calculator" ? "Est. returns" : calc?.title === "RD Calculator" ? "Est. Returns" : calc?.title === "FD Calculator" ? "Est Returns" : calc?.title === "Mortgage Payment" || calc?.title === "Loan Amortization" ? "Total Payment" : calc?.title === "Compound Interest" ? "Total Value" : calc?.title === "NPS Calculator" ? "Interest Earned" : calc?.title === "Lumpsum Calculator" ? "Est. Returns" : calc?.title === "Post Office MIS Calculator" ? "Invested Amount" : "Cost Increase"}</span></div>
                    <span className="text-sm font-black text-blue-600">{formatCurrency(
                      calc?.title === "SIP Calculator"
                        ? estReturns
                        : calc?.title === "RD Calculator"
                        ? estReturns
                        : calc?.title === "FD Calculator"
                        ? estReturns
                        : calc?.title === "ROI Calculator"
                        ? finalAmount
                        : calc?.title === "Auto Loan"
                        ? finalAmount
                        : calc?.title === "Mortgage Payment"
                        ? finalAmount
                        : calc?.title === "Loan Amortization"
                        ? finalAmount
                        : calc?.title === "Compound Interest"
                        ? totalValue
                        : calc?.title === "NPS Calculator"
                        ? estReturns
                        : calc?.title === "Lumpsum Calculator"
                        ? estReturns
                        : calc?.title === "Post Office MIS Calculator"
                        ? totalInvested
                        : totalValue
                    )}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                    <div className="flex items-center gap-3"><div className={`w-2 h-2 rounded-full ${estReturns < 0 && calc?.title !== "Post Office MIS Calculator" ? 'bg-red-500' : 'bg-blue-500'}`} /><span className={`text-xs font-bold ${estReturns < 0 && calc?.title !== "Post Office MIS Calculator" ? 'text-red-600' : 'text-slate-500'}`}>{calc?.title === "SIP Calculator" ? "Total value" : calc?.title === "RD Calculator" ? "Total Value" : calc?.title === "FD Calculator" ? "Total Value" : calc?.title === "Compound Interest" ? "Principal Amount" : calc?.title === "NPS Calculator" ? "Maturity Amount" : calc?.title === "Inflation Calculator" ? "Future cost" : calc?.title === "Lumpsum Calculator" ? "Invested Amount" : calc?.title === "Post Office MIS Calculator" ? "Interest Rate" : "Total Interest"}</span></div>
                    <span className="text-sm font-black text-blue-600">{calc?.title === "Post Office MIS Calculator" ? `${returnPercentage}%` : formatCurrency(calc?.title === "SIP Calculator" ? totalValue : calc?.title === "RD Calculator" ? totalValue : calc?.title === "FD Calculator" ? totalValue : calc?.title === "Compound Interest" ? totalInvested : calc?.title === "NPS Calculator" ? results.maturityAmount : calc?.title === "Lumpsum Calculator" ? totalInvested : estReturns)}</span>
                  </div>
                  {calc?.title === "NPS Calculator" && (
                    <div className="flex justify-between items-center p-4 bg-[#f8fafc] dark:bg-slate-800/50 rounded-2xl border border-slate-50 dark:border-slate-800">
                      <div className="flex items-center gap-3"><div className="w-2 h-2 rounded-full bg-green-500" /><span className="text-xs font-bold text-slate-500">Min. Annuity Investment</span></div>
                      <span className="text-sm font-black text-blue-600">{formatCurrency(results.minAnnuityInvestment)}</span>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Info Sections: Grid 1 col on mobile, 2 col on desktop */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-6">
        <div className="space-y-6 md:space-y-8">
          <div className="bg-white dark:bg-slate-900 rounded-[2rem] p-6 sm:p-8 border border-slate-100 dark:border-slate-800 text-left">
            <h3 className="font-bold mb-4 flex items-center gap-3">
              <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg"><BookOpen size={18} className="text-blue-600" /></div>
              Calculation Formula
            </h3>
            <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed mb-6">
              {dynamicConfig.formulaText}
            </p>
            <div className="bg-slate-50 dark:bg-slate-950 p-3 sm:p-3 rounded-2xl border border-slate-100 dark:border-slate-800 text-left overflow-x-auto max-w-full">
              {/* LaTeX Formula Rendering */}
              <span className="text-blue-600 dark:text-blue-400 font-bold text-xs sm:text-sm whitespace-nowrap inline-block min-w-max">
                {dynamicConfig.formulaLatex}
              </span>
            </div>
            <p className='text-slate-400 text-[11px] mt-4 leading-relaxed'>
              {dynamicConfig.formulaVars}
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-[2rem] p-6 sm:p-8 border border-slate-100 dark:border-slate-800 text-left">
            <h3 className="font-bold mb-6 flex items-center gap-3">
              <div className="p-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg"><Zap size={18} className="text-emerald-600" /></div>
              Best Use Cases
            </h3>
            <div className="space-y-4 text-left">
              {dynamicConfig.useCases.map((text: string, idx: number) => (
                <div key={idx} className="flex items-start gap-3">
                  <CircleCheck size={18} className="text-emerald-500 mt-0.5 shrink-0" />
                  <span className="text-sm font-medium text-slate-600 dark:text-slate-400">{text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[2rem] p-6 sm:p-10 border border-slate-100 dark:border-slate-800 text-left">
          <h3 className="font-bold mb-8 flex items-center gap-2">
            <div className="p-2 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg"><FileText size={18} className="text-indigo-600" /></div>
            DEFINITION
          </h3>
          <div className="space-y-8 text-left">
            {config.definitions.map((term: { title: string; desc: string }, i: number) => (
              <div key={i}>
                <p className="font-black text-blue-600 dark:text-blue-400 text-sm mb-2 uppercase tracking-wide text-left">{term.title}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-medium">{term.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);
  }

export default CalculatorDetail;
