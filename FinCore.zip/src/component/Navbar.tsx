import React, { useState, useEffect } from 'react';
import { Search, ChevronDown, Moon, Sun } from 'lucide-react';

const Navbar: React.FC = () => {
  // 1. Initialize state
  const [isDarkMode, setIsDarkMode] = useState(false);

  // 1.5. Effect to set initial state based on localStorage or system preference
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      setIsDarkMode(savedTheme === 'dark');
    } else {
      setIsDarkMode(window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
  }, []);

  // 2. Effect to apply the class to the <html> element
  useEffect(() => {
    if (isDarkMode) {
      console.log('darkmode on');
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  return (
    <nav className="flex items-center justify-between px-4 sm:px-6 md:px-16 py-4 bg-white dark:bg-slate-900 border-b border-gray-100 dark:border-slate-800 sticky top-0 z-50 transition-colors duration-300">
      <div className="flex items-center gap-10">
        {/* Logo */}
        <div className="flex items-center gap-3 cursor-pointer group">
          <div className="w-10 h-10 bg-slate-900 dark:bg-blue-600 rounded-xl flex items-center justify-center transition-transform group-hover:scale-105">
            <span className="text-white font-bold text-xl">F</span>
          </div>
          <span className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">FinCore</span>
        </div>
        
        
      </div>

      
      

      {/* Right Actions */}
      <div className="flex items-center gap-4">
        <button
          onClick={toggleTheme}
          className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer flex items-center justify-center"
          aria-label="Toggle theme"
        >
          {isDarkMode ? <Sun size={20} className="text-yellow-500" /> : <Moon size={20} className="text-slate-600 dark:text-slate-300" />}
        </button>
       
      </div>
    </nav>
  );
};

export default Navbar;