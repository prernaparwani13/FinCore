import React from 'react';
import { ChevronRight } from 'lucide-react';

const CalculatorListItem = ({ title, description, category, icon, onClick }: any) => {
  return (
    <div className="group bg-white dark:bg-slate-800 rounded-2xl p-4 md:p-6 border border-transparent hover:border-blue-500/30 hover:shadow-xl transition-all flex flex-col md:flex-row md:items-center md:justify-between cursor-pointer" onClick={onClick}>
      <div className="flex items-center gap-4 md:gap-6 pointer-events-none mb-4 md:mb-0">
        <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center justify-center text-xl">
          {icon}
        </div>
        <div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-white group-hover:text-blue-600 transition-colors">
            {title}
          </h3>
          <p className="text-slate-400 dark:text-slate-500 text-sm font-medium">{description}</p>
        </div>
      </div>

      <div className="flex items-center justify-between md:justify-end md:gap-8 pointer-events-none">
        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500/60 md:mr-4">
          {category}
        </span>
        <div className="w-10 h-10 rounded-full border border-slate-100 dark:border-slate-700 flex items-center justify-center text-slate-300 group-hover:bg-blue-500 group-hover:text-white group-hover:border-blue-500 transition-all">
          <ChevronRight size={20} />
        </div>
      </div>
    </div>
  );
};

export default CalculatorListItem;