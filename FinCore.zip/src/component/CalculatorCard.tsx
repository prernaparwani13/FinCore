import React from 'react';
import { ChevronRight } from 'lucide-react';

interface CalculatorCardProps {
  title: string;
  description: string;
  category: string;
  icon: React.ReactNode;
  onClick: () => void;
}

const CalculatorCard: React.FC<CalculatorCardProps> = ({ 
  title, 
  description, 
  category, 
  icon, 
  onClick 
}) => {
  return (
    <div 
      onClick={onClick}
      /* Reduced padding (p-6) and height to force horizontal rectangle */
      /* Added border transition for the "whole card" blue line effect */
      className="group relative bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-6 md:p-8 lg:p-10 border-2 border-transparent hover:border-blue-600 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col cursor-pointer overflow-hidden ring-1 ring-slate-100 dark:ring-slate-800"
    >
      <div className="flex justify-between items-start mb-4">
        {/* Compact Icon */}
        <div className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-lg flex items-center justify-center text-lg text-blue-600 transition-colors group-hover:bg-blue-50">
          {icon}
        </div>
        <div className="w-10 h-10 rounded-full border border-slate-100 dark:border-slate-700 flex items-center justify-center text-slate-300 group-hover:bg-blue-500 group-hover:text-white group-hover:border-blue-500 transition-all">
          <ChevronRight size={20} />
        </div>
      </div>

      <div className="flex-grow">
        <h3 className="text-lg font-black text-slate-800 dark:text-white mb-1  tracking-tight">
          {title}
        </h3>
        <p className="text-slate-400 dark:text-slate-500 text-xs font-medium leading-relaxed line-clamp-2">
          {description}
        </p>
      </div>

      <div className="mt-4 flex justify-between items-center pt-3 border-t border-slate-50 dark:border-slate-800/50">
        <span className="text-[9px] font-black uppercase tracking-widest text-blue-600">
          {category}
        </span>
        <span className="text-[9px] font-bold text-slate-300 uppercase">
          Free
        </span>
      </div>
    </div>
  );
};

export default CalculatorCard;