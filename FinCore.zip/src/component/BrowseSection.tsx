import React from 'react';
import { Search, LayoutGrid, List } from 'lucide-react';

interface BrowseSectionProps {
  viewMode: 'grid' | 'list';
  setViewMode: (mode: 'grid' | 'list') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
}

const categories = ["All", "Mortgage & Loans", "Retirement", "Investment", "Business", "Tax & Salary"];

const BrowseSection: React.FC<BrowseSectionProps> = ({ 
  viewMode, setViewMode, searchQuery, setSearchQuery, selectedCategory, setSelectedCategory 
}) => {
  return (
    <div className="w-full bg-slate-100 dark:bg-slate-900/50 pt-16 pb-8 px-2 sm:px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-10">
          <div>
            <h2 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white tracking-tight">Browse Calculators</h2>
            <p className="text-slate-500 dark:text-slate-400 font-medium mt-2">Find the perfect tool for your next financial move.</p>
          </div>
          <div className="relative w-full max-w-md">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search calculators..."
              className="w-full bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl py-3 px-4 pr-10 shadow-sm focus:ring-4 focus:ring-blue-500/5 outline-none cursor-pointer dark:text-white text-sm"
            />
            <Search className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
          </div>
        </div>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Category buttons for medium and larger screens */}
          <div className="hidden md:flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 md:px-5 py-2.5 rounded-full text-sm font-bold transition-all  ${
                  selectedCategory === cat
                    ? 'bg-slate-900 dark:bg-blue-600 text-white shadow-lg'
                    : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 hover:bg-slate-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Category dropdown for small screens */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="md:hidden w-full max-w-xs bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl py-4 px-6 shadow-sm focus:ring-4 focus:ring-blue-500/5 outline-none cursor-pointer dark:text-white text-slate-900"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          {/* Toggle buttons */}
          <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-xl p-1.5 shadow-sm self-start md:self-auto">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-lg transition-all cursor-pointer ${viewMode === 'grid' ? 'bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <LayoutGrid size={18} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg transition-all cursor-pointer ${viewMode === 'list' ? 'bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <List size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrowseSection;